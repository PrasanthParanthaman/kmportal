
const data = [
    {sno: 1, acronym: 'A/P', description: 'Account Payable'},
    {sno: 2, acronym: 'A/R', description: 'Accounts Receivable'},
    {sno: 3, acronym: 'ABA', description: 'American Bankers Association'},
    {sno: 4, acronym: 'ABS', description: 'Asset Backed Securities'},
    {sno: 5, acronym: 'ACE', description: 'Automated Communication Environment'},
    {sno: 6, acronym: 'ACH', description: 'Automated Clearing House'},
    {sno: 7, acronym: 'ACR', description: 'Auction Condition Report'},
    {sno: 8, acronym: 'AF', description: 'Automotive Finance Suite'},
    {sno: 9, acronym: 'AHFC', description: 'American Honda Finance Corporation'},
    {sno: 10, acronym: 'AHM', description: 'American Honda Motors'},
    {sno: 11, acronym: 'ALM', description: 'Application Life Cycle Management'},
    {sno: 12, acronym: 'APCO', description: 'Automobile Protection Corporation'},
    {sno: 13, acronym: 'API', description: 'Application Programming Interference'},
    {sno: 14, acronym: 'APPCOND', description: 'Conditionally Approved'},
    {sno: 15, acronym: 'APR', description: 'Annual Percentage Rate'},
    {sno: 16, acronym: 'ATV', description: 'All Terrain Vehicle'},
    {sno: 17, acronym: 'B2C', description: 'Business To Customer'},
    {sno: 18, acronym: 'BCR', description: 'Bank Control Record'},
    {sno: 19, acronym: 'BKC', description: 'Bankruptcy'},
    {sno: 20, acronym: 'BOP', description: 'Beginning Of Period'},
    {sno: 21, acronym: 'C LOS', description: 'Canada Loan Originating System'},
    {sno: 22, acronym: 'CASS', description: 'Customer Account Servicing System'},
    {sno: 23, acronym: 'CB', description: 'Credit Bureau'},
    {sno: 24, acronym: 'CCR', description: 'Critical Change Request'},
    {sno: 25, acronym: 'CDIA', description: 'Customer Data Industry Rescission'},
    {sno: 26, acronym: 'CEFT', description: 'Customer Electronic Fund Transfer'},
    {sno: 27, acronym: 'CFA', description: 'Captive Finance Application'},
    {sno: 28, acronym: 'CITS', description: 'Cognizant Intelligent Test Scripter'},
    {sno: 29, acronym: 'CO', description: 'Charge Off'},
    {sno: 30, acronym: 'COP', description: 'Customer Auction Plan'},
    {sno: 31, acronym: 'CP', description: 'Contract Processing'},
    {sno: 32, acronym: 'CR', description: 'Change Request'},
    {sno: 33, acronym: 'CRAFT', description: 'Cognizant Reusable Automation Framework for Testing'},
    {sno: 34, acronym: 'CRM', description: 'Client Relationship Management'},
    {sno: 35, acronym: 'CRRG', description: 'Credit Report Resource Guide'},
    {sno: 36, acronym: 'CSI', description: 'Client Satisfaction Index'},
    {sno: 37, acronym: 'CTI', description: 'Current Tax Index'},
    {sno: 38, acronym: 'DAG', description: 'Data Group'},
    {sno: 39, acronym: 'DLP', description: 'Data Loss Prevention tool'},
    {sno: 40, acronym: 'DSP', description: 'Digital Sales Platform'},
    {sno: 41, acronym: 'DT', description: 'Dealer Tracker'},
    {sno: 42, acronym: 'E2E', description: 'End to End'},
    {sno: 43, acronym: 'EDW', description: 'Enterprise Data Warehouse'},
    {sno: 44, acronym: 'ET', description: 'Early Term'},
    {sno: 45, acronym: 'FCRA', description: 'Fair Credit Reporting Act'},
    {sno: 46, acronym: 'Federal Ev', description: 'Federal Electric Vehicle'},
    {sno: 47, acronym: 'FICO', description: 'Fair Isaac Corporation'},
    {sno: 48, acronym: 'FIS', description: 'Financial Information System'},
    {sno: 49, acronym: 'FLA', description: 'Foreign Language Acknowledgement'},
    {sno: 50, acronym: 'FT', description: 'Full Term'},
    {sno: 51, acronym: 'FTE', description: 'Functional Tester'},
    {sno: 52, acronym: 'FTP', description: 'Fund Transfer Pricing'},
    {sno: 53, acronym: 'GAP', description: 'Guaranteed Asset Protection'},
    {sno: 54, acronym: 'GL', description: 'General Ledger'},
    {sno: 55, acronym: 'HAM', description: 'Honda of American Manufacturing'},
    {sno: 56, acronym: 'HCFI', description: 'Honda Canada Finance Incorporate'},
    {sno: 57, acronym: 'HCM', description: 'Honda of Canada Manufacturing'},
    {sno: 58, acronym: 'HFS', description: 'Honda Financial Services'},
    {sno: 59, acronym: 'HLE', description: 'High Level Estimation'},
    {sno: 60, acronym: 'IAP', description: 'Index Applicability Plan'},
    {sno: 61, acronym: 'ID', description: 'Identification'},
    {sno: 62, acronym: 'IDC', description: 'Indirect Cost'},
    {sno: 63, acronym: 'IDR', description: 'Dealer Accrual Group'},
    {sno: 64, acronym: 'IGS', description: 'In Goods Standard'},
    {sno: 65, acronym: 'iN', description: 'Interactive Network'},
    {sno: 66, acronym: 'IR', description: 'Involuntary Repossession'},
    {sno: 67, acronym: 'ISMS', description: 'Information Security Management System'},
    {sno: 68, acronym: 'IVR', description: 'Interactive Voice Response'},
    {sno: 69, acronym: 'KPI', description: 'Key Performance Indicator'},
    {sno: 70, acronym: 'LEV', description: 'Lease End Value'},
    {sno: 71, acronym: 'LTV', description: 'Loan To Value'},
    {sno: 72, acronym: 'MC', description: 'Motorcycle'},
    {sno: 73, acronym: 'ME', description: 'Marine Equipment'},
    {sno: 74, acronym: 'MMS', description: 'Mechanized Suspense'},
    {sno: 75, acronym: 'MSRP', description: 'Manufacturer\'s Suggested Rated Place'},
    {sno: 76, acronym: 'MUV', description: 'Multiple Utility Vehicle'},
    {sno: 77, acronym: 'NSC', description: 'National Servicing Centers'},
    {sno: 78, acronym: 'NSF', description: 'Non Sufficient Fund'},
    {sno: 79, acronym: 'OASIS', description: 'One Acquisition Solution for Integrated Services'},
    {sno: 80, acronym: 'PADP', description: 'Pre Approved Debit Plan'},
    {sno: 81, acronym: 'PARMS', description: 'Policy Administration Retrieval And Management System'},
    {sno: 82, acronym: 'PE', description: 'Power Equipment'},
    {sno: 83, acronym: 'PG', description: 'Payment Gateway'},
    {sno: 84, acronym: 'PO', description: 'Paid Off'},
    {sno: 85, acronym: 'PWC', description: 'Personal Water Craft'},
    {sno: 86, acronym: 'QC', description: 'Quality Centre'},
    {sno: 87, acronym: 'RMS', description: 'Remarketing System'},
    {sno: 88, acronym: 'RV', description: 'Residual Value'},
    {sno: 89, acronym: 'RVIC', description: 'Residual Value Insurance Claim'},
    {sno: 90, acronym: 'RVIP', description: 'Residual Value Insurance Premium'},
    {sno: 91, acronym: 'SF', description: 'SalesForce'},
    {sno: 92, acronym: 'SLA', description: 'Service Level Agreement'},
    {sno: 93, acronym: 'SME', description: 'Subject Matter Expert'},
    {sno: 94, acronym: 'SOC', description: 'Substitution Of Collateral'},
    {sno: 95, acronym: 'SOW', description: 'Statement of Work'},
    {sno: 96, acronym: 'SOX', description: 'Sarbanes-Oxley Act'},
    {sno: 97, acronym: 'SSN', description: 'Social Security Number'},
    {sno: 98, acronym: 'SSO', description: 'Single Sign On'},
    {sno: 99, acronym: 'SYS APPROVE', description: 'System Approved'},
    {sno: 100, acronym: 'T&L', description: 'Treasury Tax and Loan'},
    {sno: 101, acronym: 'TOE', description: 'Transfer Of Equity'},
    {sno: 102, acronym: 'UAT', description: 'User Acceptance Testing'},
    {sno: 103, acronym: 'UFT', description: 'Unified Functional Test'},
    {sno: 104, acronym: 'UW OVW', description: 'Underwriting Overview'},
    {sno: 105, acronym: 'VET', description: 'Voluntary Early Termination'},
    {sno: 106, acronym: 'VIN', description: 'Vehicle Identification Number'},
    {sno: 107, acronym: 'VR', description: 'Voluntary Repossession'},
    {sno: 108, acronym: 'VSC', description: 'Vehicle Service Contract'}
];


let currentPage = 1;
const rowsPerPage = 10;

function displayTable(page) {
    const start = (page - 1) * rowsPerPage;
    const end = start + rowsPerPage;
    const paginatedData = data.slice(start, end);

    const tableBody = document.getElementById('table-body');
    tableBody.innerHTML = '';

    paginatedData.forEach((row, index) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${row.sno}</td>
            <td>${row.acronym}</td>
            <td>${row.description}</td>
        `;
        tableBody.appendChild(tr);
    });

    document.getElementById('prev-btn').disabled = page === 1;
    document.getElementById('next-btn').disabled = page === Math.ceil(data.length / rowsPerPage);
}

function nextPage() {
    if (currentPage < Math.ceil(data.length / rowsPerPage)) {
        currentPage++;
        displayTable(currentPage);
    }
}

function prevPage() {
    if (currentPage > 1) {
        currentPage--;
        displayTable(currentPage);
    }
}

displayTable(currentPage);
