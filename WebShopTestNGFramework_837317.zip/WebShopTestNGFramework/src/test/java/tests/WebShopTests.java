package tests;
 
import org.testng.annotations.*;
import pages.*;
import utils.DriverUtils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
 
public class WebShopTests {
 
    WebDriver driver;
 
    @BeforeMethod
    public void setup() {
        DriverUtils.initDriver();
        driver = DriverUtils.getDriver();
    }
 
    @AfterMethod
    public void tearDown() {
        DriverUtils.quitDriver();
    }
 
    @Test(priority = 1, groups = {"Smoke"})
    public void registrationTest() {
        driver.findElement(By.linkText("Register")).click();
        RegistrationPage reg = new RegistrationPage(driver);
        reg.register("Gloria", "Bogan", "gloria" + System.currentTimeMillis() + "@mail.com", "Test1234");
    }
 
    @Test(priority = 2, dataProvider = "loginData", groups = {"Regression"})
    public void loginTest(String email, String password) {
        driver.findElement(By.linkText("Log in")).click();
        LoginPage login = new LoginPage(driver);
        login.login(email, password);
    }
 
    @DataProvider(name = "loginData")
    public Object[][] getLoginData() {
        return new Object[][] {
            {"test123_email@mail.com", "Test1234"}
        };
    }
 
    @Test(priority = 3, invocationCount = 2, groups = {"Regression", "Search"})
    public void searchTest() throws InterruptedException {
        SearchPage search = new SearchPage(driver);
        search.searchBook("computing");
    }
}