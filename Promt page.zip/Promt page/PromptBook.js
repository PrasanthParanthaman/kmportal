function showModal(title, desc) {
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-desc').textContent = desc;
    document.getElementById('modal-body').innerHTML = `
      <button class="copy-btn" onclick="copyText('${desc.replace(/'/g, "\\'")}')">Copy Prompt</button>
    `;
    document.getElementById('popupModal').style.display = 'block';
  }

  function showSqlModal() {
    // Custom titles for each SQL prompt
    const sqlPrompts = [
      {
        title: "Paid Off Accounts Query",
        query: "Give me the records of the accounts which are Paid off for finance type retail, lease , balloon"
      },
      {
        title: "Expired Account Query",
        query: "Display the account numbers which have vehicle type as honda and term expired is greater than 16 and the company of the account should be AHFC AND the address type is garaging and the primary customer's address state is NH"
      },
      {
        title: "Open Balloon Finance Query",
        query: "Give me the account numbers which are open status for balloon finance type"
      }
    ];
  
    // Clear existing content
    document.getElementById('modal-title').textContent = "";
    document.getElementById('modal-desc').textContent = "";
    const container = document.getElementById("modal-body");
    container.innerHTML = "";
  
    // Create each query block
    sqlPrompts.forEach(({ title, query }) => {
      const block = document.createElement("div");
      block.style.marginBottom = "20px";
  
      const heading = document.createElement("h4");
      heading.textContent = title;
      heading.style.color = "#fff";
      heading.style.marginBottom = "5px";
  
      const queryText = document.createElement("pre");
      queryText.textContent = query;
      queryText.style.color = "#fff";
      const copyBtn = document.createElement("button");
      copyBtn.className = "copy-btn";
      copyBtn.textContent = "Copy Query";
      copyBtn.style.fontSize = "12px";      // Smaller text size
      copyBtn.style.padding = "4px 8px"; 

      copyBtn.onclick = () => {
        navigator.clipboard.writeText(query).then(() => {
          copyBtn.textContent = "Copied!";
          setTimeout(() => {
            copyBtn.textContent = "Copy Query";
          }, 5000);
        });
      };
  
      block.appendChild(heading);
      block.appendChild(queryText);
      block.appendChild(copyBtn);
      container.appendChild(block);
    });
  
    document.getElementById("popupModal").style.display = 'block';
  }
  
  function copyText(text) {
    navigator.clipboard.writeText(text)
      .then(() => {
        const btn = document.querySelector('.copy-btn');
        btn.textContent = 'Copied!';
        setTimeout(() => {
          btn.textContent = 'Copy Prompt';
        }, 1500);
      })
      .catch(err => {
        console.error('Copy failed:', err);
      });
  }

  function closeModal() {
    document.getElementById('popupModal').style.display = 'none';
  }

  window.onclick = function(event) {
    const modal = document.getElementById('popupModal');
    if (event.target === modal) {
      modal.style.display = "none";
    }
  }