class Chatbox {
    constructor() {
        this.args = {
            openButton: document.querySelector('.chatbox__button'),
            chatBox: document.querySelector('.chatbox__support'),
            sendButton: document.querySelector('.send__button')
        };

        this.state = false;
        this.messages = [];
    }

    display() {
        const { openButton, chatBox, sendButton } = this.args;

        openButton.addEventListener('click', () => this.toggleState(chatBox));
        sendButton.addEventListener('click', () => this.onSendButton(chatBox));

        const node = chatBox.querySelector('input');
        node.addEventListener("keyup", ({ key }) => {
            if (key === "Enter") {
                this.onSendButton(chatBox);
            }
        });
    }

    toggleState(chatbox) {
        this.state = !this.state;

        if (this.state) {
            chatbox.classList.add('chatbox--active');
        } else {
            chatbox.classList.remove('chatbox--active');
        }
    }

    // onSendButton(chatbox) {
    //     const messageInput = chatbox.querySelector('input');
    //     const msg = messageInput.value.trim();

    //     if (msg === "") return;

    //     this.selfReply(msg);

    //     setTimeout(() => {
    //         this.processMessage(msg);
    //     }, 500);

    //     messageInput.value = "";
    // }

    // selfReply(message) {
    //     this.appendMessage(message, "message message-personal");
    // }

//     appendMessage(message, className) {
//         const messageContainer = document.querySelector('.chatbox__messages');
//         messageContainer.innerHTML += `<div class="${className}">${message}</div>`;
//         $(".chatbox__messages").scrollTop($(".chatbox__messages")[0].scrollHeight);
//     }

//     botReply(message) {
//         $('.message.loading').remove();
//         this.appendMessage(message, "message new");
//         $('.message-input').prop('disabled', false);
//         $('.message-input').attr("placeholder", "Type message...");
//         $('.message-input').focus();
//     }

//     processMessage(msg) {
//         let response = "";
//         switch (msg.toLowerCase()) {
//             case "hi":
//                 response = "Hi there, how can I help?";
//                 break;

//             case "thanks":
//             case "thank":
//             case "thank you":
//                 response = "I'm glad I could help.";
//                 break;

//             case "what is repossession":
//             case "repossession":
//             case "reposession meaning":
//             case "reposession means":
//                 response = "When the customer does not make payment on time, CAR/CSR Explore various options such as making collection calls and sending collection letters to bring the account current. If the efforts fail, the vehicle is Repossessed.";
//                 break;

//             case "when was honda founded and who were the driving force behind its growth?":
//             case "about honda":
//             case "when was honda founded":
//             case "honda founded":
//                 response = "Honda was founded in 1948 by Mr. Soichiro Honda and Mr. Takeo Fujisawa, who are credited for the company’s rapid expansion and success.";
//                 break;

//             case "what are the projects available in honda":
//             case "honda projects":
//             case "available honda projects":
//             case "projects":
//             case "project":
//                 response = "Currently, there are 3 projects available in Honda.";
//                 break;

//             case "who is honda company' founder":
//             case "founder of honda":
//             case "founder":
//             case "who is the founder of honda?":
//                 response = "Soichiro Honda";
//                 break;

//             default:
//                 response = "My apologies. I didn't understand the question.";
//                 break;
//         }
//         this.botReply(response);
//     }

//     scrollToBottom(container) { container.scrollTop = container.scrollHeight; }
 }

document.addEventListener("DOMContentLoaded", function () {
    const chatbox = new Chatbox();
    chatbox.display();

    $(".send__button").click(function () {
        chatbox.onSendButton(chatbox.args.chatBox);
    });

    $(window).on('keydown', function (e) {
        if (e.which === 13) {
            chatbox.onSendButton(chatbox.args.chatBox);
            return false;
        }
    });
});
