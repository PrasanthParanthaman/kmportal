package pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
 
public class SearchPage {
    WebDriver driver;
 
    public SearchPage(WebDriver driver) {
        this.driver = driver;
    }
 
    By searchBox = By.id("small-searchterms");
    By searchButton = By.cssSelector("input[value='Search']");
    By booksCategory = By.linkText("Books");
    By computerBook = By.linkText("Computing and Internet");
 
    public void searchBook(String bookName) {
        driver.findElement(booksCategory).click();
        driver.findElement(searchBox).sendKeys(bookName);
        driver.findElement(searchButton).click();
        driver.findElement(computerBook).click();
    }
}