package pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
 
public class RegistrationPage {
    WebDriver driver;
 
    public RegistrationPage(WebDriver driver) {
        this.driver = driver;
    }
 
    By firstName = By.id("FirstName");
    By lastName = By.id("LastName");
    By email = By.id("Email");
    By password = By.id("Password");
    By confirmPassword = By.id("ConfirmPassword");
    By registerBtn = By.id("register-button");
 
    public void register(String fname, String lname, String mail, String pass) {
        driver.findElement(firstName).sendKeys(fname);
        driver.findElement(lastName).sendKeys(lname);
        driver.findElement(email).sendKeys(mail);
        driver.findElement(password).sendKeys(pass);
        driver.findElement(confirmPassword).sendKeys(pass);
        driver.findElement(registerBtn).click();
    }
}