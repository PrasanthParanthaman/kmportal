const message_container = document.querySelector('.chatbox__messages');

var msg;
var welcome1 = 'Hi. Welcome to Kite support. How can I help you?'
// var welcome2 = 'I am here to help you with your queries related to UPS';
// var welcome3 = 'You can use keywords for your queries';

var badAlert = 'Bad Request / Improper Language Is Not Tolerated';
var badRequest = [];

const myDecipher = decipher('Key123');

for (var i = 0; i < cipheredProfaneWordsList.length; i++) {
    badRequest.push(myDecipher(cipheredProfaneWordsList[i]));
}

function htmlDecode(input) {
    var doc = new DOMParser().parseFromString(input, "text/html");
    return doc.documentElement.textContent;
}
 
function newBotMsgAttach(msg){
    var msgNew = document.createElement("div");
    msgNew.className = "message-new";
    // var avatar = document.createElement('figure');
    // avatar.className = "avatar";
    // var botImg = document.createElement('img');
    // botImg.src = "serve/images/BOT.gif";
	let urlRegex = /(https?:\/\/[^\s]+)/g;
    let formattedText = msg.replace(urlRegex, (url) => {
    return `<a class="bot-response" href="${url}" target="_blank">${url}</a>`;
    });
	
    var contentHolderDiv = document.createElement('div');
    contentHolderDiv.textContent = msg;
    var temp = contentHolderDiv.textContent;
    contentHolderDiv.textContent='';
	if (msg.includes('Google')){
        contentHolderDiv.innerHTML= temp;
    }else{
        contentHolderDiv.innerHTML= formattedText;
    }
	
    // avatar.append(botImg);
    // msgNew.append(avatar);
    msgNew.append(contentHolderDiv);
    message_container.append(msgNew);
}

function newUserMsgAttach(msg){
    var msgNew = document.createElement("div");
    msgNew.className = "message message-personal";
    var contentHolderDiv = document.createElement('div');
    contentHolderDiv.textContent=msg;
    msgNew.append(contentHolderDiv);
    message_container.append(msgNew);
}

 newBotMsgAttach(welcome1);
// newBotMsgAttach(welcome2);
// newBotMsgAttach(welcome3);

function botReply(message,addQuery,addResponse) {
    $.get("/getBotResponse", { msg: message,addQry: addQuery,addResp: addResponse }).done(function (data) {
        $('.chatbox__messages.loading').remove();
        data = htmlDecode(data);
        if (data.includes("<\\n>")) {
            var messageSplitter = data.split("<\\n>");
            for (var i = 0; i < messageSplitter.length; i++) {
                newBotMsgAttach(messageSplitter[i]);
            }
        }
        else {
            newBotMsgAttach(data);
        }
        $(".chatbox__messages").scrollTop($(".chatbox__messages")[0].scrollHeight);
        $('.message-input').prop('disabled', false);
        $('.message-input').attr("placeholder", "Write a message...");
        $('.message-input').focus();
    });
}

function botReplyDirect(message) {
    $('.chatbox__messages.loading').remove();
    if (message.includes("<\\n>")) {
        var messageSplitter = message.split("<\\n>");
        for (var i = 0; i < messageSplitter.length; i++) {
            newBotMsgAttach(messageSplitter[i]);
        }
    }
    else {
        newBotMsgAttach(message);
    }
    $(".chatbox__messages").scrollTop($(".chatbox__messages")[0].scrollHeight);
    $('.message-input').prop('disabled', false);
    $('.message-input').attr("placeholder", "Write a message...");
    $('.message-input').focus();  
}

function selfReply(message) {
    $('.clickOptions').parent().parent().remove();
    newUserMsgAttach(message);
    $('.message-input').prop('disabled', true);
    $('.message-input').val("");
    $('.message-input').attr("placeholder", "Waiting For Response");
    var loaderDiv = document.createElement("div");
    loaderDiv.className = "message loading";
    // var loaderFigure = document.createElement("figure");
    // loaderFigure.className = "avatar";
    // var botImg = document.createElement("img");
    // botImg.src = "serve/images/BOT.gif";
    // loaderFigure.append(botImg);
    // loaderDiv.append(loaderFigure)
    message_container.append(loaderDiv);
    $(".chatbox__messages").scrollTop($(".chatbox__messages")[0].scrollHeight);
}

function addQueryForm() {
    Swal.fire({
        title: 'Add Query',
        html: `<input type="text" id="query" class="swal2-input" placeholder="Type your query here..."><brz>
<textarea id="response"class="swal2-textarea" placeholder="Type your response here..."></textarea>`,
        confirmButtonText: 'Proceed',
        showCancelButton: true,
        focusConfirm: false,
        preConfirm: () => {
            const query = Swal.getPopup().querySelector('#query').value
            const response = Swal.getPopup().querySelector('#response').value
            if (query.replace(/^\s+|\s+$/g, "").length == 0) {
                Swal.showValidationMessage("Please Enter the Query Properly")
            }
            else if (response.replace(/^\s+|\s+$/g, "").length == 0) {
                Swal.showValidationMessage("Please Enter the Response Properly")
            }
            return {
                query: query,
                response: response
            }
        }
    }).then((result) => {
        if (result.value) {
            var query = result.value.query.trim();
            var response = result.value.response.trim();
            if (response.includes("\n")) {
                var currentResponse = response.split("\n");
                for (var i = 0; i < currentResponse.length; i++) {
                    currentResponse[i] = currentResponse[i].trim()
                }
                response = currentResponse.join("<\\n>")
            }
            botReply("",query.replace(/\s\s+/g, ' '),response)
        }
        else if (result.dismiss == 'cancel') {
            botReplyDirect("Process Cancelled.");
        }
    })
}

function processInputMessage() {
    msg = $('.message-input').val().trim().replace(/\s\s+/g, ' ');
    if (new RegExp("\\b(" + badRequest.join("|").toLowerCase() + ")\\b", "g").test(msg.toLowerCase())) {
        $('.message-input').val("");
        Swal.fire({
            icon: 'warning',
            title: 'Warning!',
            text: badAlert,
        })
    }
    else if (msg.toLowerCase() == "add query") {
        selfReply(msg);
        addQueryForm();
    }
    else {
        if (msg.replace(/^\s+|\s+$/g, "").length != 0) {
            selfReply(msg);
            botReply(msg);
        } else {
            $('.message-input').val("");
        }
    }
}

$('.message-submit').click(function () {
    processInputMessage();
});

$(window).on('keydown', function (e) {
    if (e.which == 13) {
        processInputMessage();
        return false;
    }
})

function clickOptions(element) {
    selfReply(element.textContent);
    botReply(element.textContent);
}

// function openForm() {
//     if (!isOpen()) {
//         document.getElementById("myForm").style.display = "block";
//         document.getElementById("openForm").style.display = "none";
//     }
// }

// function closeForm() {
//     if (isOpen()) {
//         document.getElementById("myForm").style.display = "none";
//         document.getElementById("openForm").style.display = "block";
//     }
// }
// function isOpen() {
//     if (document.getElementById("myForm").style.display == "block" && document.getElementById("openForm").style.display == "none") {
//         return true;
//     }
//     else {
//         return false;
//     }
// }

$(document).ready(function () {
    $('#iconAction1').click(function () {
        // openForm();
        $('.message-input').val("Onboarding");
        processInputMessage();
    });
    $('#iconAction2').click(function () {
        // openForm();
        $('.message-input').val("Logistics Videos");
        processInputMessage();
    });
    $('#iconAction3').click(function () {
        // openForm();
        botReplyDirect('Some ML Terms:<br><button class="clickOptions" onClick="clickOptions(this)">Cross Docking</button><br><button class="clickOptions" onClick="clickOptions(this)">Back Order</button><br><button class="clickOptions" onClick="clickOptions(this)">Bill Of Lading</button>')
    });
    $('#iconAction4').click(function () {
        // openForm();
        $('.message-input').val("UPS");
        processInputMessage();
    });

});