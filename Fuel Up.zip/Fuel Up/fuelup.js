$(document).ready(function () {
  $(".custom-carousel .item").click(function () {
    $(".custom-carousel .item").not($(this)).removeClass("active");
    $(this).toggleClass("active");
  });
});

document.addEventListener("DOMContentLoaded", function() { 
  const gameSection = document.getElementById("gameSection"); 
  const detailsBox = document.getElementById("detailsBox"); 
  const cardImage = document.getElementById("cardImage"); 
  const top10Image = document.getElementById("top10Image"); 
  const backtoFuelUp = document.getElementById("backtoFuelUp"); 
  document.querySelectorAll(".custom-carousel .item a").forEach(function(link) { 
    link.addEventListener("click", function(e) { 
      e.preventDefault(); 
      const cardImageSrc = this.getAttribute("data-card"); 
      const top10ImageSrc = this.getAttribute("data-top"); 
      cardImage.setAttribute("src", cardImageSrc); 
      top10Image.setAttribute("src", top10ImageSrc); 
      gameSection.style.display = "none"; 
      detailsBox.style.display = "flex"; 
    }); 
  }); 
  backtoFuelUp.addEventListener("click", function(e) {
    e.preventDefault(); 
    detailsBox.style.display = "none"; 
    gameSection.style.display = "flex"; 
  }); 
});
